#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include "map.h"
class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

    void initScene();//initialize
    void playGame();//启动游戏
    void updatePosition();//更新元素坐标
    void paintEvent(QPaintEvent *);//绘制到屏幕
    map M_map;
    QTimer m_timer;//定时器
};
#endif //WIDGET_H
