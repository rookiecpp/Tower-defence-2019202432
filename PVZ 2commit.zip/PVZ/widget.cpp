#include "widget.h"
#include "config.h"
#include<QIcon>
#include<QPainter>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    initScene();//���ó�ʼ������
    playGame();
}

Widget::~Widget()
{
}

void Widget::initScene()
{
    setFixedSize(GAME_WIDTH,GAME_HEIGHT);//���ô��ڹ̶��ߴ�
    setWindowTitle(GAME_TITLE);//���ñ���
    m_timer.setInterval(10);//��ʱ����ʼ������
}

void Widget::playGame()
{
    m_timer.start();
    connect(&m_timer, &QTimer::timeout,[=](){
        updatePosition();
        update();
    });
}

void Widget::updatePosition()
{

}

void Widget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,GAME_WIDTH,GAME_HEIGHT,M_map.m_map);
}

