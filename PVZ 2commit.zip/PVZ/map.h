#ifndef MAP_H
#define MAP_H
#include<QPixmap>

class map
{
public:
    map();

    QPixmap m_map;

    int m_map_pos;
};

#endif // MAP_H
