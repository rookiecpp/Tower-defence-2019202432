#include "map.h"
#include "config.h"

map::map()
{
    m_map.load("D:/homework/PVZ/res/mapday.jpg");

    m_map_pos = GAME_HEIGHT;;
}
