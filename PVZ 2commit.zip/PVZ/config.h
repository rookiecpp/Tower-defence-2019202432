#ifndef CONFIG_H
#define CONFIG_H

#define GAME_WIDTH  888 //����
#define GAME_HEIGHT 803 //�߶�
#define GAME_TITLE "TowerDfence"
#endif // CONFIG_H
