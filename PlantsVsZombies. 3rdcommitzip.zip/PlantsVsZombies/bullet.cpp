#include "bullet.h"
#include <QPoint>
#include <QVector2D>
#include <QPainter>

Bullet::Bullet():QObject(0)
{

}

void Bullet::setBullet(QPoint startPos, QPoint targetPos, QString fileName)
{
    pixmap.load(fileName);
    this->startPos = startPos;
    this->targetPos = targetPos;
    this->currentPos = startPos;
    speed = 1.0;
    this->bullet_rect.setWidth(pixmap.width());
    this->bullet_rect.setHeight(pixmap.height());
    this->bullet_rect.moveTo(QPoint(currentPos));
}

void Bullet::move()
{
    QVector2D vector(targetPos - startPos);
    vector.normalize();
    currentPos = currentPos + vector.toPoint()*speed;
    bullet_rect.moveTo(currentPos);
    if(currentPos.x()>2340){
        bullet_free = true;
        currentPos = startPos;
    }
}

void Bullet::draw(QPainter *painter)
{
    painter->drawPixmap(currentPos,pixmap);
}
