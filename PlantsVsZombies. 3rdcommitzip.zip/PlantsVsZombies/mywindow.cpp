#include "mywindow.h"
#include"mybutton.h"
#include"plants.h"
#include"bullet.h"
#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include<QAction>
#include<QMenu>
#include<QtDebug>
#include<QTimer>
//static int x_unit = 0;
//static int y_unit = 0;
MyWindow::MyWindow(QWidget *parent) : QWidget(parent)
{
    this->setFixedSize(1170,540);//游戏界面大小
    MyButton *backToMain = new MyButton();//返回主界面按钮
    backToMain->setPos(":/res/BackButton.jpg",0,0,400,400);
    backToMain->setParent(this);
    connect(backToMain,&MyButton::clicked,this,[=](){
        emit chooseback();
    });
    MywindowInit();

    QTimer *timer = new QTimer(this);
    timer->setInterval(10);
    connect(timer,&QTimer::timeout,this,[=](){
        shoot();
        UpdateSecen();
    });
    timer->start(10);

}

void MyWindow::paintEvent(QPaintEvent *)//绘制游戏界面
{
    QPainter painter(this);
    QPixmap pixmap(":/res/map2.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    for(int i = 0;i < 6;i++){
        for(int j = 0;j < 9;j++){
            if(Gatling[i][j].p_free==false){
                Gatling[i][j].draw(&painter);
                for(int k =0 ;k < 50;k++){
                    if(Gatling[i][j].pea[k].bullet_free==false){
                        Gatling[i][j].pea[k].draw(&painter);
                        update();
                        //qDebug("paint");
                    }
                }

            }
        }
    }

    update();
}
void MyWindow::MywindowInit()
{
    setButtonAndPlants();

}

void MyWindow::setButtonAndPlants()
{
    for(int i = 0; i < 6; i++){
        for(int j = 0; j < 9; j++){
            button[i][j].setPos(":/res/PointerUP.gif",318+88*j,145+88*i,32,36);
            button[i][j].setParent(this);;
            QMenu *set_menu = new QMenu(this);
            QAction *set_A_plant = new QAction("peashooter",this);
            connect(set_A_plant,&QAction::triggered,this,[=](){
                Gatling[i][j].setPlant(QPoint(318+88*j,65+88*i));
            });
            QAction *delete_a_plant = new QAction("delete",this);
            connect(delete_a_plant,&QAction::triggered,this,[=](){
                Gatling[i][j].p_free=true;
            });
            set_menu->addAction(set_A_plant);
            set_menu->addAction(delete_a_plant);
            button[i][j].setMenu(set_menu);
        }

    }

}

void MyWindow::shoot()
{
    for(int i = 0;i < 6;i++){
        for(int j = 0;j < 9;j++){
            if(Gatling[i][j].p_free==false){
                if(Gatling[i][j].recorder==100){
                    Gatling[i][j].recorder = 0;
                    if(Gatling[i][j].p_free==false){
                        for(int k = 0; k<50; k++){
                            if(Gatling[i][j].pea[k].bullet_free==true){
                                Gatling[i][j].pea[k].bullet_free=false;
                               //qDebug("shoot");
                               break;
                            }
                        }
                    }
                 }
            else{
                    Gatling[i][j].recorder++;
                }
            }
        }
    }
}

void MyWindow::UpdateSecen()
{
    for(int i = 0;i < 6;i++){
        for(int j = 0;j < 9;j++){
            if(Gatling[i][j].p_free==false){
                for(int k = 0;k < 50 ;k++){
                    if(Gatling[i][j].pea[k].bullet_free==false){
                        Gatling[i][j].pea[k].move();//qDebug("update");

                    }
                }
            }
        }
    }update();
}


