#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include"mybutton.h"
#include"mywindow.h"
Mainwindow::Mainwindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Mainwindow)
{
    this->setFixedSize(1170,540);//设置界面大小
    ui->setupUi(this);
    MyButton *btn = new MyButton();//开始游戏按钮
    btn->setPos(":/res/startbutton.jpg",450,480,800,800);
    btn->setParent(this);
    MyButton *exit_button = new MyButton();//退出按钮
    exit_button->setPos(":/res/ExitButton.jpg",0,0,400,400);
    exit_button->setParent(this);
    connect(exit_button,&QPushButton::clicked,this,&Mainwindow::close);
    MyWindow *menu = new MyWindow;//游戏界面
    connect(btn,&QPushButton::clicked,this,[=](){
        this->hide();
        menu->show();
    });
    connect(menu,&MyWindow::chooseback,this,[=](){
        menu->hide();
        this->show();
    });
}

Mainwindow::~Mainwindow()
{
    delete ui;
}
void Mainwindow::paintEvent(QPaintEvent *)//绘制主界面
{
    QPainter painter(this);
    QPixmap pixmap(":/res/mainwindow.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}
