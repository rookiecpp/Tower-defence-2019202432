#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
QT_BEGIN_NAMESPACE
namespace Ui { class Mainwindow; }
QT_END_NAMESPACE

class Mainwindow : public QWidget
{
    Q_OBJECT

public:
    void paintEvent(QPaintEvent *);
    Mainwindow(QWidget *parent = nullptr);
    ~Mainwindow();

private:
    Ui::Mainwindow *ui;
};
#endif // MAINWINDOW_H
