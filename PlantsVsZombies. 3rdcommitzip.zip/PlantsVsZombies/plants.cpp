#include "plants.h"
#include <QPoint>
#include <QString>
#include <QPixmap>
#include <QPainter>
Plants::Plants():pixmap(":/res/GatlingPea.gif")
{

}

void Plants::setPlant(QPoint _pos)
{
    p_free = false;
    p_rect.setWidth(pixmap.width());
    p_rect.setHeight(pixmap.height());
    pos = _pos;
    for(int i = 0;i < 50;i++){
        pea[i].setBullet(QPoint(_pos.x()+74,_pos.y()),QPoint(2340,_pos.y()),":/res/ProjectilePea.png");
    }
}

void Plants::draw(QPainter *painter)//绘制植物
{
    painter->drawPixmap(pos,pixmap);
}
