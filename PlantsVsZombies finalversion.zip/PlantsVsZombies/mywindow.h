#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include "plants.h"
#include"mybutton.h"
#include"config.h"
#include"zombies.h"
#include"bullet.h"
#include <QList>
#include <QTimer>
#include <QFont>
class MyWindow : public QWidget
{
    Q_OBJECT
public:
    explicit MyWindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void MywindowInit();
    void setButtonAndPlants();
    void shoot();
    void UpdateSecen();
    void zombieShow();
    void showInfo(QPainter *painter);
    int money = MONEY;
    int count_zombie = 500;
    int zombie_times = 0;
    int zombie_wave = 1;
    QFont font;
    QPixmap Money_show;
private:
    MyButton button[6][9];
    Plants Gatling[6][9];
    Zombies zombies[100];
signals:
    void chooseback();//返回按钮信号
};

#endif // MYWINDOW_H
