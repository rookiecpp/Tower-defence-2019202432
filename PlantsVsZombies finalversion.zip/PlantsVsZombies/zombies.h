#ifndef ZOMBIES_H
#define ZOMBIES_H


#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QMovie>
#include"config.h"
class Zombies : public QObject
{
    Q_OBJECT
public:
    Zombies();
    void setZombies(QPoint startPos, QPoint targetPos);
    void move();
    void draw(QPainter *painter);
public:
    QPoint startPos;
    QPoint targetPos;
    QPoint currentPos;
    QPixmap pixmap;
    QMovie movie;
    qreal speed;
    bool zombie_free = true;
    QRect zombie_rect;
    int zombie_health = ZOMBIE_HEALTH;
signals:

};

#endif // ZOMBIES_H
