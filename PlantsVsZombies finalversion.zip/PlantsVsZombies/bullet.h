#ifndef BULLET_H
#define BULLET_H
#include "config.h"
#include <QObject>
#include <QPoint>
#include <QPixmap>
class Bullet : public QObject
{
    Q_OBJECT
public:
   Bullet();
   void setBullet(QPoint startPos, QPoint targetPos, QString fileName);
   void move();
   void draw(QPainter *painter);
public:
   QPoint startPos;
   QPoint targetPos;
   QPoint currentPos;
   QPixmap pixmap;
   qreal speed;
   bool bullet_free = true;
   QRect bullet_rect;
signals:

};

#endif // BULLET_H
