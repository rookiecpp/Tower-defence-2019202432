#ifndef PLANTS_H
#define PLANTS_H

#include <QObject>
#include <QPoint>
#include <QString>
#include <QPixmap>
#include <QPainter>
#include <QMovie>
#include "config.h"
#include "bullet.h"
class Plants : public QObject
{
    Q_OBJECT
public:
    Plants();//植物构造函数
    void setPlant(QPoint _pos);
    void draw(QPainter *painter);
public:
    Bullet pea[BULLEI_NUM];
    QPoint pos;//位置
    QPixmap pixmap;//图片
    QPixmap tmp_pix;
    QMovie movie;
    bool p_free = true;
    QRect p_rect;
    int recorder = 0;
    int target = 100;
    int plants_health = PLANTS_HEALTH;
signals:

};

#endif // PLANTS_H
