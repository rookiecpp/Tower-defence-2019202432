#include "mywindow.h"
#include"mybutton.h"
#include"plants.h"
#include"bullet.h"
#include<cstdlib>
#include<ctime>
#include <QWidget>
#include<QPainter>
#include<QPixmap>
#include<QPaintEvent>
#include<QPushButton>
#include<QAction>
#include<QMenu>
#include<QtDebug>
#include<QTimer>
#include<QSound>
#include"config.h"

MyWindow::MyWindow(QWidget *parent) : QWidget(parent)
{
    this->setFixedSize(1170,540);//游戏界面大小
    MyButton *backToMain = new MyButton();//返回主界面按钮
    backToMain->setPos(":/res/BackButton.jpg",0,0,400,400);
    backToMain->setParent(this);
    connect(backToMain,&MyButton::clicked,this,[=](){
        emit chooseback();
    });
    QSound::play(":/res/Faster.wav");
    MywindowInit();
    QTimer *timer = new QTimer(this);
    timer->setInterval(10);
    connect(timer,&QTimer::timeout,this,[=](){
        shoot();
        zombieShow();
        UpdateSecen();
    });
    timer->start(10);

}

void MyWindow::paintEvent(QPaintEvent *)//绘制游戏界面
{
    QPainter painter(this);
    QPixmap pixmap(":/res/map2.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    painter.drawPixmap(220,0,Money_show.width(),Money_show.height(),Money_show);
    showInfo(&painter);
    for(int i = 0;i < 6;i++){
        for(int j = 0;j < 9;j++){
            if(Gatling[i][j].p_free==false){
                Gatling[i][j].draw(&painter);
                for(int k =0 ;k < BULLEI_NUM;k++){
                    if(Gatling[i][j].pea[k].bullet_free==false){
                        Gatling[i][j].pea[k].draw(&painter);
                        update();
                        //qDebug("paint");
                    }
                }

            }
        }
    }
    for (int i = 0;i <100 ;i++) {
        if(zombies[i].zombie_free==false){
            zombies[i].draw(&painter);
        }
    }
    update();
}
void MyWindow::MywindowInit()
{
    setButtonAndPlants();
}

void MyWindow::setButtonAndPlants()
{
    Money_show.load(":/res/money.png");
    for(int i = 0; i < 6; i++){
        for(int j = 0; j < 9; j++){
            button[i][j].setPos(":/res/PointerUP.gif",318+88*j,145+88*i,32,36);
            button[i][j].setParent(this);;
            QMenu *set_menu = new QMenu(this);
            QAction *set_A_plant = new QAction("加特林射手",this);
            connect(set_A_plant,&QAction::triggered,this,[=](){
                Gatling[i][j].setPlant(QPoint(318+88*j,65+88*i));
                if(money>=GATLING_MONEY){
                    Gatling[i][j].p_free = false;
                    money -=GATLING_MONEY;
                }
            });
            QAction *delete_a_plant = new QAction("删除",this);
            connect(delete_a_plant,&QAction::triggered,this,[=](){
                Gatling[i][j].target = 100;
                Gatling[i][j].p_free=true;
                money+=10;
            });
            QAction *upgrade = new QAction("升级",this);
            connect(upgrade,&QAction::triggered,this,[=](){
               if(money>=10){
                    Gatling[i][j].target = 50;
                    money-=10;
               }
            });
            set_menu->addAction(set_A_plant);
            set_menu->addAction(delete_a_plant);
            set_menu->addAction(upgrade);
            button[i][j].setMenu(set_menu);
        }

    }

}

void MyWindow::shoot()
{
    for(int i = 0;i < 6;i++){
        for(int j = 0;j < 9;j++){
            if(Gatling[i][j].p_free==false){
                if(Gatling[i][j].recorder>=Gatling[i][j].target){
                    Gatling[i][j].recorder = 0;
                    if(Gatling[i][j].p_free==false){
                        for(int k = 0; k<BULLEI_NUM; k++){
                            if(Gatling[i][j].pea[k].bullet_free==true){
                                Gatling[i][j].pea[k].bullet_free=false;
                               break;
                            }
                        }
                    }
                 }
            else{
                    Gatling[i][j].recorder++;
                }
            }
        }
    }
}

void MyWindow::UpdateSecen()
{
    for(int i = 0;i < 6;i++){
        for(int j = 0;j < 9;j++){
            if(Gatling[i][j].p_free==false){
                for(int o = 0;o<100;o++){
                    if(zombies[o].zombie_free==false){
                        if(zombies[o].zombie_rect.intersects(Gatling[i][j].p_rect)){
                            zombies[o].speed = 0.0;
                            Gatling[i][j].plants_health--;
                        if(Gatling[i][j].plants_health==0){
                                Gatling[i][j].plants_health = PLANTS_HEALTH;
                                Gatling[i][j].p_free = true;
                                zombies[o].speed = ZOMBIES_SPEED;
                            }
                        }
                    }
                }
                for(int k = 0;k < BULLEI_NUM ;k++){
                    if(Gatling[i][j].pea[k].bullet_free==false){
                        Gatling[i][j].pea[k].move();//qDebug("update");
                        for(int p =0;p<100;p++){
                            if(zombies[p].zombie_free==false){
                                if(zombies[p].zombie_rect.intersects(Gatling[i][j].pea[k].bullet_rect)){
                                    Gatling[i][j].pea[k].bullet_free = true;
                                    Gatling[i][j].pea[k].currentPos = Gatling[i][j].pea[k].startPos;
                                    zombies[p].zombie_health--;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    for(int i = 0; i < 100; i++){
        if(zombies[i].zombie_health==0){
            money+=10;
            zombies[i].zombie_free = true;
            zombies[i].currentPos = zombies[i].startPos;
            zombies[i].zombie_health = ZOMBIE_HEALTH;
        }
        if(zombies[i].zombie_free==false){
            zombies[i].move();
        }
    }
    update();
}

void MyWindow::zombieShow()
{
    srand((unsigned)time(NULL));
    int path;
    if(zombie_times==count_zombie){
        for(int i = 0;i < 100; i++){
            if(zombies[i].zombie_free==true){
                path = rand()%5;
                int u = 88;
                switch (path) {
                case 0:zombies[i].setZombies(QPoint(1340,u*path),QPoint(0,u*path));break;
                case 1:zombies[i].setZombies(QPoint(1340,u*path),QPoint(0,u*path));break;
                case 2:zombies[i].setZombies(QPoint(1340,u*path),QPoint(0,u*path));break;
                case 3:zombies[i].setZombies(QPoint(1340,u*path),QPoint(0,u*path));break;
                case 4:zombies[i].setZombies(QPoint(1340,u*path),QPoint(0,u*path));break;
                }
                zombies[i].zombie_free = false;
                zombie_times = 0;
                zombie_wave++;
                if(zombie_wave==10){
                    count_zombie = 100;
                }
                break;
            }
        }
    }
    else{
        zombie_times++;
    }
}

void MyWindow::showInfo(QPainter *painter)
{
    painter->setRenderHint(QPainter::Antialiasing, true);
    painter->setPen(Qt::red);
    font.setFamily("Microsoft YaHei");
        // 大小
        font.setPointSize(20);
         //斜体
        font.setItalic(false);
         //设置下划线
        font.setUnderline(false);
         //设置上划线
        font.setOverline(false);
         //设置字母大小写
        font.setCapitalization(QFont::SmallCaps);
        // 设置字符间距
        font.setLetterSpacing(QFont::AbsoluteSpacing, 20);
        // 设置加粗
        font.setBold(true);
        // 使用字体
        painter->setFont(font);
        painter->setFont(font);
        painter->drawText(QPointF(230,30), QString("%1").arg(money));
        /*QPainterPath path;
        path.addText(QPointF(230,30), font, QString("%1").arg(money));
        painter->drawPath(path);*/

}


