#ifndef CONFIG_H
#define CONFIG_H
#define BULLEI_NUM 100
#define ZOMBIE_HEALTH 6
#define PLANTS_HEALTH 20
#define ZOMBIES_SPEED 0.501
#define GATLING_MONEY 10
#define MONEY 50
#define BULLET_SPEED 2.0
#endif // CONFIG_H
