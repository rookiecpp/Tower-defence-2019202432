#include "zombies.h"
#include "config.h"
#include <QPoint>
#include <QVector2D>
#include <QPainter>
Zombies::Zombies() : QObject(0)
{
    pixmap.load(":/res/Zombie.gif");
    movie.setFileName(":/res/Zombie.gif");
    movie.setSpeed(100);
}

void Zombies::setZombies(QPoint startPos, QPoint targetPos)
{
    this->startPos = startPos;
    this->targetPos = targetPos;
    this->currentPos = startPos;
    speed = ZOMBIES_SPEED;
    this->zombie_rect.setWidth(pixmap.width()/10);
    this->zombie_rect.setHeight(pixmap.height()/2);
    this->zombie_rect.moveTo(QPoint(currentPos.x(),currentPos.y()+zombie_rect.height()));
    movie.start();
}

void Zombies::move()
{
    QVector2D vector(targetPos - startPos);
    vector.normalize();
    currentPos = currentPos + vector.toPoint()*speed;
    zombie_rect.moveTo(QPoint(currentPos.x()+pixmap.width()/2,currentPos.y()+zombie_rect.height()));
    if(currentPos.x()<0){
        zombie_free = true;
        currentPos = startPos;
        movie.stop();
    }
}

void Zombies::draw(QPainter *painter)
{
        painter->drawPixmap(currentPos,movie.currentPixmap());
        //painter->drawPixmap(currentPos,pixmap);
        //painter->drawRect(zombie_rect);
}
