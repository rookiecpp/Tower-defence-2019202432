#include "mybutton.h"
#include <QPixmap>
#include<QPropertyAnimation>
MyButton::MyButton():QPushButton(0)
{

}


void MyButton::setPos(QString pix, int x, int y, int width, int height)
{
    QPixmap pixmap(pix);
    this->setFixedSize(pixmap.width(),pixmap.height());//按钮大小
    this->setStyleSheet("QPushButton{border:Opx}");
    this->setIcon(pixmap);//图片
    this->setIconSize(QSize(width,height));//图标大小
    this->move(x,y);//位置
}
