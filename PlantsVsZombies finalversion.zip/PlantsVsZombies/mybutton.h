#ifndef MYBUTTON_H
#define MYBUTTON_H
#include<QPropertyAnimation>
#include <QWidget>
#include <QPushButton>
#include <QString>
class MyButton : public QPushButton
{
    Q_OBJECT
public:
    MyButton();//button构造函数
    void setPos(QString pix, int x, int y, int width, int height);
signals:

};

#endif // MYBUTTON_H
